*****************************************************
Neverwinter Nights   -   README.TXT
*****************************************************

Neverwinter Nights Linux (x86) v1.29

There are three ways to install Neverwinter Nights for Linux.

I) Copy from a Windows installation:
   1) Copy the following files from a Windows installation of Neverwinter
      Nights (updated to 1.29) into a directory called, for example, 
      nwn:
          ambient/*
          data/*
	  dmvault/*
	  hak/*
	  localvault/*
	  modules/*
	  music/*
	  nwm/*
	  override/*
	  portraits/*
	  saves/*
	  servervault/*
	  texturepacks/*
	  chitin.key
	  patch.key
	  dialog.tlk
	  dialogF.tlk (French, German, Italian, and Spanish)
      If you are using ftp to transfer the files, be sure to transfer 
      them in binary mode.

   2) Install Linux binaries.
      i) Dowload Linux NWN binaries, for links see 
         http://nwn.bioware.com/downloads/linuxclient.html
     ii) Extract the archive into your nwn directory
    iii) Run ./fixinstall from your nwn directory.

   Note: If your Windows installation was a partial install, add the following
   lines to your nwn.ini file (substituting your CD mount point if it is not
   /mnt/cdrom) and mount your Play Disc.

   [Alias]
   CD0=/mnt/cdrom
   AMBIENT=/mnt/cdrom/ambient
   MUSIC=/mnt/cdrom/music
 
   For information on updating to a full install, see 
   http://nwn.bioware.com/support/techfaq.html#05

III) Download game resources:
   1) Download NWN 1.29 game resources
      See http://nwn.bioware.com/downloads/linuxclient.html

   2) Extract game resources to desired location.

   3) Download Linux NWN binaries and language files 
      See http://nwn.bioware.com/downloads/linuxclient.html

   4) Extract these archives into the nwn directory created in step (2)


To run Neverwinter Nights, run ./nwn or ./dmclient from your nwn directory 
to run the player client or DM client respectively.


The Neverwinter Nights client uses the Simple DirectMedia Layer (SDL)
library, see readme-SDL.txt for more details.
    http://www.libsdl.org/

By default, Neverwinter Nights will dynamically load the SDL 1.2.5 library
found in the lib directory.  If you wish to load a different version or 
build of this library, remove ./lib from LD_LIBRARY_PATH in the nwn script.


Bug Reporting:

Bugs may be reported to nwlinux@bioware.com.  Please visit 
http://nwn.bioware.com/downloads/linuxclient.html for the latest information.


NEVERWINTER NIGHTS Developed by BioWare Corp. 
 
C 2002 Atari Inc., S.A. All Rights Reserved. Manufactured
and marketed by Atari Inc.., New York, NY. Portions
C 2002 Bioware Corp. BioWare Aurora Engine copyright 1997-2002 BioWare Corp.
All Rights Reserved. BioWare, the BioWare Aurora Engine, and the
BioWare Logo are trademarks of BioWare Corp. All Rights Reserved.
Neverwinter Nights, Forgotten Realms, the Forgotten Realms logo,
Dungeons & Dragons logo, Dungeon Master, D&D, and the Wizards of the Coast
logo are trademarks owned by Wizards of the Coast, Inc., a subsidiary of
Hasbro, Inc. and are used by Atari Inc., S.A. under license.
All Rights Reserved. Windows and Windows 95/98/2000 are registered trademarks
of Microsoft Corporation. All Rights Reserved. The ratings icon is a trademark
of the Interactive Digital Software Association. All other trademarks and
copyrights are the property of their respective owners.


This file contains helpful information, late-breaking news and a description 
of certain functions which were not implemented when the On-Line Help feature 
and manual were created.


Optimizing Gameplay
-------------------

If you are experiencing slowdowns or poor performance, we recommend that 
you try turning down Options settings such as:
	
	(Video Options) Graphics quality
	(Video Options)	Creature shadow detail
	(Video Options)	Enable environment shadows
	(Video Advanced Options) Grass
	(Video Advanced Options) Creature wind
	(Video Advanced Options) Number of dynamic lights
	(Video Advanced Options) Shadow casting lights
	(Video Advanced Options) Anti aliasing
	(Video Advanced Options) Texture animations
	(Video Advanced Options) Environment mapping
	(Video Advanced Options) Visual effects high
		
Certain options such as shiny water, dynamic lighting, and anti aliasing 
may only be available on the recommended video cards and higher.

A recommended system will be able to play the game with most of 
the advanced options turned on while a minimum spec system may require 
some of these options to be turned off.


The Official Campaign
---------------------

The Prelude is designed as a purely single-player experience.

The rest of the official campaign (chapters 1, 1e, 2, 2e, 3 and 4) 
has been designed as primarily either a single-player or one-party 
multiplayer experience.

Modules you create using the toolset or download can of course be single-player, 
multi-player co-op/one-party, or multiplayer with multiple parties/PVP.

Before moving between any of the Chapters or End Chapters in our 
campaign, be aware that you can never go back to the previous chapter 
(to collect discarded equipment, or complete subplots).  
Take what you need before you leave a chapter!

The official campaign has been designed with the following level 
progression in mind:

	Prelude:   Levels  1 to  3
	Chapter 1: Levels  3 to  8
	Chapter 2: Levels  7 to 15
	Chapter 3: Levels 13 to 17
	Chapter 4: Levels 15+


Manual Errata
-------------

 (1) Index of Charts & Tables (p.0) - In some printings of the manual, the coil
     ring binding has punched through the page numbers listed in the Index of
     Charts & Tables. The Index is reprinted below:

	Table 1: Monster difficulty Categories...................36
	Table 2: Ranger Favored Enemy Groups.....................66
	Table 3: Ability Scores..................................72
	Table 4: Quickchat Commands.............................104
	Table 5: Movement Speed Penalties.......................112
	Table 6: Toolset Layout.................................158
	Table 7: Skill Points Per Class.........................173
	Table 8: Weapons List...................................173
	Table 9: Armor Stats....................................176
	Table 10: Two-Weapon Fighting Penalties.................177
	Table 11: Lore Values...................................178
	Table 12: Use Magic Device Skill........................178
	Table 13: Base Saves and Base Attacks for All Classes...179
	Table 14: Bard Known Spells and Spells Per Day..........180
	Table 15: Cleric Spells Per Day.........................181
	Table 16: Clerical Domains..............................182
	Table 17: Druid Spells Per Day..........................184
	Table 18: Fighter Bonus Feats...........................185
	Table 19: Monk Attacks, AC and Speed Bonuses............186
	Table 20: Paladin and Ranger Spells Per Day.............187
	Table 21: Rogue Bonus Feats.............................187
	Table 22: Sorcerer Known Spells and Spells Per Day......188
	Table 23: Wizard Spells Per Day.........................189
	Table 24: Wizard Bonus Feats............................189
	Table 25: Alignment Grid................................190
	Table 26: Racial Size...................................190
	Table 27: Skill Chart...................................191
	Table 28: Feats by Type.................................192

 (2) Direct 3D support (p.5)  NWN does not support Direct 3D rendering

 (3) Monk Abilities (p.61) - Monks gain Cleave as a free bonus feat at Level 1.

 (4) Ranger Abilities (p.66) - Rangers do not receive the benefits of their
     Ambidexterity and Two-Weapon Fighting bonus feats when wearing medium or heavy
     armor.

 (5) Ranger Abilities (p.66) - Some specific examples that fall into the different
     Favored Enemy groups are as follows:

	Aberration..........Hook Horror
	Animal..............Chicken
	Beast...............Grey Render
	Construct...........Iron Golem
	Dragon..............Gold Dragon
	Elemental...........Fire Elemental
	Fey.................Sprite
	Giant...............Hill Giant
	Goblinoid...........Bugbear
	Monstrous Humanoid..Minotaur
	Orc.................Orc
	Reptilian Humanoid..Lizardman
	Magical Beast.......Gargoyle
	Outsider............Baalor
	Shapechanger........Wererat
	Undead:.............Zombie
	Vermin..............Spider

 (6) Skills (p.76), Feats (p.87), Associates (p.111), Spell Icons (p.193) - Many
     icons have been updated since the printing of the manual. To see the icons as
     they appear in-game, view the NWN_OnlineManual.pdf file in your Docs directory.

 (7) Skills (p.77) Be careful when using the Disable Trap skill. If you fail your
     Disarm check by 10 or more while distracted by combat, you will trigger the
     trap instead.

 (8) Feats (p.95) - The Rapid Shot feat does not apply to crossbows, due to the
     long reload times on these weapons.

 (9) Feats (p.95) - For balancing reasons, the Sap feat was cut subsequent to the
     printing of the manual.

(10) Feats (p.97) - The Base DC for the Stunning Fist feat is 15, not 10.

(11) Feats (p.98) - Ranged weapons always apply Dexterity modifiers to their attack
     rolls. For that reason, the Weapon Finesse feat has no bearing on light
     crossbows, shuriken, slings, and throwing axes.

(12) Spells (p.113) - Spell durations may vary according to the Difficulty Settings
     defined in the Game Options interface. If a spell has a duration that is less
     than or equal to 3 rounds, however, its duration will remain static across all
     settings.

(13) Bard Spells (p.125), Sorcerer/Wizard Spells (p.138) - The Ghostly visage spell
     now also applies a 10% concealment bonus.

(14) Bard Spells (p.126), Cleric Spells (p.128), Sorcerer/Wizard Spells (p.139) -
     The Find Traps spell no longer modifies your search skill. It now detects and
     destroys all traps within 30 meters of the caster.

(15) Bard Spells (p.127), Druid Spells (p.133), Sorcerer/Wizard Spells (p.140) -
     The Ice Storm spell now does an additional 1d6 cold damage for every 3 caster
     levels.

(16) Bard Spells (p.127), Sorcerer/Wizard Spells (p.142) - The Ethereal Visage
     spell now also applies a 25% concealment bonus.

(17) Cleric Spells (p.130) - Only clerics of the Death domain receive the 5th-Level
     Summon Shadows spell. It is not available as part of the standard Cleric spell
     list.

(18) Druid Spells (p.134) - The Storm of Vengeace spell has been added to the
     Druid's 9th level spell list. Storm of Vengeance does 3d6 acid damage each
     round.

(19) Druid Spells (p.134) - Druids do not gain the spell Greater Restoration as a
     7th level spell.

(20) Sorcerer/Wizard Spells (p.139) - The Negative Energy Burst spell now does an
     additional 1 point of Strength damage for every 4 caster levels.

(21) Sorcerer/Wizard Spells (p.140) - The Lesser Spell Breach spell now also lowers
     the target's Spell Resistance by 3.

(22) Sorcerer/Wizard Spells (p.142) - The Greater Spell Breach spell now also
     lowers the target's Spell Resistance by 5.

(23) Equipment, Magic items, and Treasure (p.149) - When you mouse over an item
     icon, it will be highlighted in one of three colors, the colors and their
     significance is as follows:  

	Blue  = Unidentified
	Red   = Unusable/Unequippable  
		(note that some objects may show up as red until 
		you place them in your inventory)
	White = Useable

(24) Weapons (p.152) - The Bastard Sword is an Exotic Weapon, not a Martial one.

(25) Table 8: Weapons List (p.174) - Spears and Quarterstaffs are both classified
     as Large weapons. This means that small creatures, such as gnomes and
     halflings, will not be able to wield them.

(26) Table 8: Weapons List (p.175) - Bastard Swords are Medium-sized weapons, not
     Large ones. This means that small creatures, such as gnomes and halflings,
     will be able to wield them.

(27) Table 23: Wizard Spells Per Day (p.189) - The correct spell progression for
     Wizards is as follows:

		       -----Base Spells per Day------
	
	  Spell Level:  0  1  2  3  4  5  6  7  8  9
		       ------------------------------	
		    1 | 3  1  -  -  -  -  -  -  -  -
		    2 | 4  2  -  -  -  -  -  -  -  -
		    3 | 4  2  1  -  -  -  -  -  -  -
		    4 | 4  3  2  -  -  -  -  -  -  -
		C   5 | 4  3  2  1  -  -  -  -  -  -
		l   6 | 4  3  3  2  -  -  -  -  -  -
		a   7 | 4  4  3  2  1  -  -  -  -  -
		s   8 | 4  4  3  3  2  -  -  -  -  -
		s   9 | 4  4  4  3  2  1  -  -  -  -
		   10 | 4  4  4  3  3  2  -  -  -  -
		L  11 | 4  4  4  4  3  2  1  -  -  -
		e  12 | 4  4  4  4  3  3  2  -  -  -
		v  13 | 4  4  4  4  4  3  2  1  -  -
		e  14 | 4  4  4  4  4  3  3  2  -  -
		l  15 | 4  4  4  4  4  4  3  2  1  -
		   16 | 4  4  4  4  4  4  3  3  2  -
		   17 | 4  4  4  4  4  4  4  3  2  1
		   18 | 4  4  4  4  4  4  4  3  3  2
		   19 | 4  4  4  4  4  4  4  4  3  3
		   20 | 4  4  4  4  4  4  4  4  4  4


Spell-caster Hints
-------------------
Spellcasters need to have high ability scores to cast high level spells.
The prime attributes for the various spell casting classes are as follows:

Wizard: Intelligence
Bard, Sorcerer: Charisma
Cleric, Druid, Ranger, Paladin: Wisdom

When you create your character and hit the Recommended button at the ability 
score page, you will be given an appropriate number of points in the prime abilities
for your chosen class.

The way the formula works is that the character can cast spells if their required
ability score is equal to or greater than 10 + the level of the spell.

For example a wizard with only 10 intelligence could only cast cantrips 
(level 0 spells). A sorcerer with a 19 charisma could cast up to 9th level spells.


Extra Functionality
--------------------

TAB KEY: Pressing this button will highlight all objects in the visible area. 
Any creatures in this area will display their name and health above their heads.

TYR'S POOL OF LOST ITEMS: In each chapter there is a pool -- normally found 
in the temple of Tyr.  This pool will contain a temple store, where for a small fee, 
players may purchase 'lost' items. These 'lost' items are items that have been 
taken away in a multiplayer game by players who have logged off, or which have 
been dropped elsewhere in the singleplayer campaign. The items are marked as 
'plot' and hence are necessary to complete the module.  In this way, if you 
ever find that you have 'lost' a critical path or required quest item in either 
singleplayer or multiplayer in the official campaign, you can obtain the 
missing item for a small fee from the pool in the temple of Tyr in the 
current chapter.

DATE and TIME: IF you move the mouse over the compass it will tell you the month day 
and time currently in the game.

General Multiplayer Info
------------------------

Please also see the Neverwinter Community webpage for more information on 
multiplayer at nwn.bioware.com.


Firewall Information
--------------------

If you are trying to connect to a Neverwinter Nights server through a 
firewall, NAT, or router, here is some information for you to help you get 
connected. First, please read the manual that came with your firewall or 
router.

Neverwinter Nights uses UDP, not TCP for its connections.

If you think that your firewall is preventing you from connecting to the 
game servers, please make sure that the following ports are open:

Ports 5120 through 5300

If you are wanting to make sure that your NAT is set up to allow the game 
to play here are some details:

Outgoing packets:
Source port: 5120-5129
Destination port: 5121-5300

Incoming packets:
Source port: 5121-5300
Destination port: 5120-5129

On the Game Client side, you can select what port your client uses. Go to 
your nwnplayer.ini file in your NWN Client Beta install directory. Find the 
following section:

[Profile]
Client Port=5120

Change this number if you need to force Neverwinter Nights to connect as a 
client on a different port.

Gamespy
-------

If you want to get a server listing via GameSpy, you'll need additional
ports to be open: 6667, 80, 27900, 28900, 29900, 29901, 13139, 6500, 6515


Advanced Multiplayer setup and NWMain, NWServer Console Commands
----------------------------------------------------------------

Please see the Neverwinter Community webpage for more information on the 
advanced multiplayer setup and how to set up a persistant world at nwn.bioware.com.


Banning and UnBanning in Multiplayer
------------------------------------

Please also see the Neverwinter Community webpage at nwn.bioware.com 
for more information on banning and unbanning.

If you accidentally ban someone and want to allow them back on your server,
don't panic, there's a simple fix. Find the nwnplayer.ini file and open it
with a text editor (notepad works well). Inside, you will find 3 headings:
	[Banned Ips]
	[Banned Players]
	[Banned CD Keys]

These represent the lists that any new server started on that machine will
use. If you want to clear them out, just delete the 3 headdings and
everything within them. If you know who you want to "unban" just remove
that specific IP, Player Name, or CD Key and make sure to renumber any
following entries so they're in order.

For example, given:
	[Banned Players]
	0=Trent
	1=Scott
	2=Paul
	3=Derek

If you want to unban Paul, but make sure that no evil Trent's, Scott's or
Derek's can get into your machine, change it to the following:
	[Banned Players]
	0=Trent
	1=Scott
	2=Derek

As well, if you want to add a group of people to the banned list, there is
limited use of wildcards in two of the lists.

For IP's, you can enter partial starting IP's to ban entire domains:
	[Banned Ips]
	0=199.168.0.1
	1=199.168.1
	2=199.168
- these are all valid, as is
	3=199.168.2.*
and even
	4=199

For Player names, you have 2 wild cards, one at the start of the name and
one at the end of the name, both can be used simultaneously. For example:
	[Banned Players]
	0=Trent
	1=*Trent
	2=Trent*
	3=*Trent*

All of these are valid entries and will work as you would expect wildcards to work.
For example: "*Trent" will ban everyone with a "Trent" at the end of their name
- "Trent*" will ban everyone with a Trent at the start of their name
- and "*Trent*" will ban everyone with a "Trent" in their name at all
(don't add the quotes). The entries are case sensitive.


CD Key Troubles
---------------

If you are having problems with your CD Key, please contact INA Support 
through the methods listed below under the Technical Support section of this readme.

Game Known Issues
-----------------

Please see the BioWare Neverwinter Community website (nwn.bioware.com) for 
a list of known compatibility issues, and work-arounds, if available. Also see the 
Infogrames support website (listed below, under the Technical Support section of this
readme).

3DFX is no longer in business; although some Voodoo 5 cards may work occasionally 
they are no longer supported by 3DFX and available drivers do not 
generally include complete OpenGL support required for Neverwinter Nights.  
Hence, 3DFX graphics cards are not supported by NWN.

The game window will not render properly if you attempt to play in a window 
while your desktop resolution is set to 800x600 or less.

Please upgrade your drivers as soon as possible.

Neverwinter Nights was designed to run under 32 bit color depth.  
Running under other bit depths will reduce the performance of the game.

There are 4 incorrect entries in the Standard Sounds Palette.  
This is an error since they are large looping ambient beds not meant 
for positional sfx.  These are:
	Weather:
		Wind Cave Loop
		Wind Chasm Loop
		Wind Grass Loop
		Draft Interior Loop

The "Memory Level=1" setting in the nwn.ini may have unintended consequences 
when set to values greater than 1.


Trademark and Copyright
-----------------------

NEVERWINTER NIGHTS was developed by BioWare Corp.  

C 2002 Infogrames Entertainment, S.A. All Rights Reserved. Portions 
C 2002 Bioware Corp. Manufactured and marketed by Infogrames, Inc., New York, NY.
BioWare Aurora Engine copyright 1997-2002 BioWare Corp. All Rights Reserved.
BioWare, the BioWare Aurora Engine, and the BioWare Logo are trademarks 
of BioWare Corp. All Rights Reserved. Neverwinter Nights, Forgotten Realms, 
the Forgotten Realms logo, Dungeons & Dragons logo, Dungeon Master, D&D, 
and the Wizards of the Coast logo are trademarks owned by Wizards of the Coast, 
Inc., a subsidiary of Hasbro, Inc. and are used by Infogrames Entertainment, 
S.A. under license. All Rights Reserved. Windows and Windows 95/98/2000 
are registered trademarks of Microsoft Corporation. All Rights Reserved. 
The ratings icon is a trademark of the Interactive Digital Software Association. 
All other trademarks and copyrights are the property of their respective owners.

Disclaimer
----------

You may not modify, enhance, supplement, create any derivative work from, 
adapt, translate, reverse engineer, decompile, disassemble or otherwise 
reduce the Software to human readable form.  


END-USER LICENSE AGREEMENT
--------------------------

INFOGRAMES, INC. ("INFOGRAMES") AND BIOWARE CORP. ("BIOWARE") ARE WILLING 
TO LICENSE THE SOFTWARE (as defined below) TO YOU ONLY ON THE CONDITION 
THAT YOU ACCEPT ALL OF THE TERMS IN THIS LICENSE (the "License") AND INDICATE 
YOUR ACCEPTANCE BY CLICKING THE "I ACCEPT" BUTTON.  PLEASE READ THE TERMS 
CAREFULLY BEFORE CLICKING THE "I ACCEPT" BUTTON.  BY CLICKING THE "I ACCEPT" 
BUTTON, AND/OR BY LOADING OR RUNNING THE SOFTWARE, BY PLACING OR COPYING THE 
SOFTWARE ONTO YOUR COMPUTER HARD DRIVE, COMPUTER RAM OR OTHER STORAGE,  
YOU ACKNOWLEDGE THAT YOU HAVE READ THIS LICENSE, UNDERSTAND IT AND AGREE 
TO BE BOUND BY ITS TERMS AND CONDITIONS.  IF YOU DO NOT AGREE TO THESE TERMS, 
DO NOT USE THE SOFTWARE AND PROMPTLY RETURN THE DISC OR CARTRIDGE IN ITS 
ORIGINAL PACKAGING TO THE PLACE OF PURCHASE.

"Software" shall mean the game, toolkit, and all other software contained 
on this disc or cartridge, all updates and/or patches thereto, any accompanying 
documentation, all on-line components, restricted-access NEVERWINTER NIGHTS 
community websites, and other BioWare or Infogrames game-related services 
(including all CD-authentication components).

1. Grant of License.  The Software is licensed to you, not sold, by Infogrames, 
and its use is subject to this License.  Infogrames grants to you a 
limited, personal, non-exclusive right to use the Software in the manner 
described in the user documentation.  If the Software is configured 
for loading onto a hard drive, you may load the Software only onto 
the hard drive of a single machine and run the Software from only 
that hard drive.  You may permanently transfer all rights Infogrames grants 
to you in this License, provided you retain no copies, you transfer all 
of the Software (including all component parts, the media and printed 
materials, the CD-authentication key, and any upgrades), and the recipient 
reads and accepts this License.  Infogrames and BioWare reserve all 
rights not expressly granted to you by this License.

2. Restrictions.  Infogrames, BioWare, and/or their suppliers own the title, 
copyright, and other intellectual property rights in the Software.  
The Software contains copyrighted material, trade secrets and other 
proprietary material.  You may not delete the copyright notices or any 
other proprietary legends on the original copy of the Software.  
You may not decompile, modify, reverse engineer, disassemble or 
otherwise reproduce the Software.  You may not copy, rent, lend, lease, 
sublicense, distribute, publicly display, create derivative works based 
upon the Software (except as provided in Section 3 below) or otherwise 
commercially exploit the Software (including, without limitation, 
hosting pay-per-play servers).  You may not electronically transmit the 
Software from one computer, console or other platform to another 
or over a network.

3. End-User Variations.  So long as you fully comply, at all times, 
with this License, Infogrames grants to you a limited, personal, revocable, 
non-exclusive right to:   (i) use the Software's toolset feature to create 
your own NEVERWINTER NIGHTS modules ("Modules"), and (ii) create your 
own modifications to work with the Software (e.g., custom data files not 
created using the toolset) (the "User Conversions", and together with the 
Modules, the "Variations").  Your rights to create Variations are subject 
to the following restrictions:  (1) your Variations must only work with 
the full commercial version of the software game NEVERWINTER NIGHTS; 
(2) your Variations must not contain modifications to any executable file; 
(3) your Variations must not contain any libelous, defamatory, pornographic, 
obscene, or other illegal material, material that is scandalous or 
invades the rights of privacy or publicity of any third party, or 
contain any trademarks, copyright-protected work or other property of 
third parties, or contain any viruses, worms, or other malicious code; 
and (4) you may not rent, sell, lease, lend, offer on a pay-per-play or 
timesharing basis or otherwise commercially exploit or commercially distribute 
your Variations (including, without limitation, hosting pay-per-play servers, 
hosting pay-per-download web-sites for Variations including sites that charge 
for bandwidth use, and independently selling Variations online, at retail, 
mail order, etc.).  Without limiting the foregoing, you expressly acknowledge 
and agree that in no event shall you have the right or license to make any 
modification (whether using the toolkit or otherwise) to any portion of 
the Software for the purpose of creating any data file, executable, 
or other derivative work  that is intended to operate in a stand-alone mode, 
with any pre-release or beta version of NEVERWINTER NIGHTS, or any software 
program other than NEVERWINTER NIGHTS.

4.  Distribution and Serving of Modules and User Conversions.  So long as you 
fully comply at all times with this License, Infogrames grants to you the 
limited, personal, revocable, non-exclusive right to:  (i) distribute your 
Modules or User Conversions by means of providing a copy of the actual Module 
or User Conversion code to other users (e.g., via ftp, email, disc copies, etc.) 
(collectively "Distribute"); and (ii) to allow other users to play your Modules 
by means of hosting your own NEVERWINTER NIGHTS server whereby you retain 
sole possession of your Module (collectively "Serve") (Serving User 
Conversions is not possible).

5.  Infogrames' and BioWare's Use of Variations.  If you Distribute, or 
permit others to Distribute, your Variations,  you hereby grant back to 
Infogrames and BioWare an irrevocable royalty-free right to use and 
distribute such Variations by any means, and to make such modifications 
thereto as Infogrames and/or BioWare deem are necessary to package, 
combine, and otherwise distribute such Variations.  If you do not wish 
to grant these rights to Infogrames and BioWare, you must not Distribute 
your Variations (although you may Serve your Modules).  Infogrames and 
BioWare will make a reasonable effort to provide credit to you in the 
event it uses or distributes your Variations, but you acknowledge that 
identifying you and/or other Variation creators may be difficult, and 
any failure by Infogrames and/or BioWare to provide credit to any person 
shall not be a breach of this License and shall not limit Infogrames' or 
BioWare's rights to use and distribute any Variation.  

6.  Revocation of Rights.  Infogrames and/or BioWare may at any time and in 
their sole discretion revoke your right to make your Variations publicly 
available (whether you are Distributing or Serving), provided that Infogrames 
and/or BioWare shall not revoke your right to Distribute a Variation 
if Infogrames and/or BioWare is, at the time of such revocation, using 
or distributing such Variation.

7. Termination.  This License is perpetual and may not be terminated except 
by mutual written agreement of the parties hereto.  However, your rights to 
use the Software, as set forth above: (i) may be terminated by you at any time, 
by destroying the Software; or (ii)  will terminate immediately without notice 
from Infogrames or BioWare if you fail to comply with any provision of 
this License (in which event, you must destroy the Software).

8. Disclaimer of Warranty on Software.  You are aware and agree that use 
of the Software and the media on which it is recorded is at your sole risk.  
The Software and the media are provided "AS IS."  Unless otherwise provided 
by applicable law, Infogrames warrants to the original purchaser of this product 
that the Software storage medium will be free from defects of materials 
and workmanship for ninety (90) days from the date of purchase.  
This warranty is void if the defect has arisen through accident, abuse, 
neglect or misapplication.

9.  Disclaimer of Other User Conduct and Gameplay Risks.  You agree 
and acknowledge that an integral feature of NEVERWINTER NIGHTS is 
the ability to play online with other game users, including playing 
Variations created by other users.  Infogrames and BioWare specifically 
disclaim any warranties relating in any way to such user-created content, 
and you agree that neither Infogrames, BioWare, their assignees or successors, 
nor any of their licensors or suppliers shall in any way be responsible 
for the content or functionality of such user content.  You further 
agree and acknowledge that while playing multi-player games, you may be 
subject to conduct of other users that may impact your own gameplay 
and characters, or that you may find objectionable or offensive.  
Infogrames and BioWare also specifically disclaim any warranties relating 
to the conduct of other users (including in-game, and in game-related forums, 
chatrooms, etc.), and you agree that neither Infogrames, BioWare, 
their assignees or successors,  nor any of their licensors or suppliers 
shall in any way be responsible for the conduct of other users.

10.  Disclaimer of Other Content.  As a service to you, Infogrames and BioWare 
may include with the Software third party drivers and other software 
utilities intended to assist you with installing and operating the Software 
(collectively, the "Drivers").  Infogrames and BioWare specifically disclaim 
any warranties relating to the Drivers, and you agree that your use of 
the Drivers is at your own risk.  The Drivers are not part of the Software 
and shall not be governed by the terms and conditions of this License 
except for and to the extent of this disclaimer.  

11.  General Disclaimer. EXCEPT AS EXPRESSLY SET FORTH ABOVE, 
INFOGRAMES AND BIOWARE EXPRESSLY DISCLAIM ALL OTHER WARRANTIES, 
EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  
NEITHER INFOGRAMES NOR BIOWARE WARRANT THAT THE FUNCTIONS CONTAINED 
IN THE SOFTWARE WILL MEET YOUR REQUIREMENTS.  NO ORAL OR WRITTEN 
INFORMATION OR ADVICE GIVEN BY INFOGRAMES, BIOWARE OR ANY INFOGRAMES 
OR BIOWARE-AUTHORIZED REPRESENTATIVE SHALL CREATE A WARRANTY OR IN ANY WAY 
INCREASE THE SCOPE OF THIS WARRANTY.  SOME JURISDICTIONS DO NOT ALLOW 
THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS MAY NOT APPLY TO YOU.

12. Limitation of Liability.  UNDER NO CIRCUMSTANCES, INCLUDING NEGLIGENCE, 
SHALL INFOGRAMES OR BIOWARE BE LIABLE FOR ANY INCIDENTAL, SPECIAL OR 
CONSEQUENTIAL DAMAGES IN CONNECTION WITH THE SOFTWARE, INCLUDING THOSE 
THAT RESULT FROM THE USE OF OR INABILITY TO USE THE SOFTWARE, EVEN IF 
INFOGRAMES OR BIOWARE HAS BEEN ADVISED OF THE POSSIBILITY OF THOSE DAMAGES.  
IN NO EVENT SHALL INFOGRAMES' OR BIOWARE'S TOTAL LIABILITY TO YOU FOR 
ALL DAMAGES, LOSSES AND CAUSES OF ACTION (WHETHER IN CONTRACT, TORT 
OR OTHERWISE) EXCEED THE AMOUNT PAID BY YOU FOR THE SOFTWARE.  
SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF 
LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THE ABOVE 
LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU.

13.  Indemnity; Injunctive Relief.  You agree to indemnify, defend and hold 
harmless Infogrames, BioWare, and each of their respective officers, 
employees, directors, agents, licensees (excluding you), successors 
and assigns from and against all losses, lawsuits, damages, causes 
of action and claims relating to and/or arising from your breach 
of this License, distribution or any use of any Variations, and/or 
any other use of the Software.  You agree that your unauthorized use 
of the Software, or any part thereof, may immediately and irreparably 
damage Infogrames, BioWare, or both of them such that neither Infogrames 
nor BioWare could be adequately compensated solely by a monetary award 
and that at Infogrames' or BioWare's option, Infogrames and/or BioWare 
shall be entitled to an injunctive order, in addition to all other 
available remedies including a monetary award, appropriately restraining 
and/or prohibiting such unauthorized use without the necessity of Infogrames 
or BioWare posting bond or other security.  Your obligations set forth 
in this Section shall survive the cancellation or termination of this License.

14.  Choice of Law and Venue.  THIS LICENSE SHALL BE GOVERNED BY 
AND CONSTRUED IN ACCORDANCE WITH CONTROLLING U.S. FEDERAL LAW AND THE LAWS 
OF THE STATE OF NEW YORK, EXCLUSIVE OF ITS CHOICE OF LAW AND/OR CONFLICTS 
OF LAW JURISPRUDENCE.  THE EXCLUSIVE VENUE FOR ALL LITIGATION REGARDING OR 
ARISING OUT OF THIS LICENSE SHALL BE IN NEW YORK COUNTY, NEW YORK, AND 
YOU AGREE TO SUBMIT TO THE JURISDICTION OF THE COURTS IN NEW YORK COUNTY, 
NEW YORK FOR ANY SUCH LITIGATION.

15.  Miscellaneous.  Nothing herein shall be deemed to supercede or derogate 
from Infogrames' or BioWare's remedies at law for any violation of this 
License or applicable law.  If any provision of this License is unenforceable, 
the rest of it shall remain in effect. This License constitutes the entire 
agreement between you, Infogrames, and BioWare with respect to the use 
of the Software and the support services (if any) and supersedes all prior 
or contemporaneous oral or written communications and representations with 
respect to the Software or any other subject matter covered by this License. 

NEVERWINTER NIGHTS Developed by BioWare Corp.  

C 2002 Infogrames Entertainment, S.A. All Rights Reserved. Portions 
C 2002 Bioware Corp. Manufactured and marketed by Infogrames, Inc., 
New York, NY. BioWare Aurora Engine copyright 1997-2002 BioWare Corp. 
All Rights Reserved. BioWare, the BioWare Aurora Engine, and the 
BioWare Logo are trademarks of BioWare Corp. All Rights Reserved. 
Neverwinter Nights, Forgotten Realms, the Forgotten Realms logo, 
Dungeons & Dragons logo, Dungeon Master, D&D, and the Wizards of the 
Coast logo are trademarks owned by Wizards of the Coast, Inc., 
a subsidiary of Hasbro, Inc. and are used by Infogrames Entertainment, 
S.A. under license. All Rights Reserved. Windows and Windows 95/98/2000 
are registered trademarks of Microsoft Corporation. All Rights Reserved. 
The ratings icon is a trademark of the Interactive Digital Software 
Association. All other trademarks and copyrights are the property of 
their respective owners.

Windows(r) and DirectX(r) are either registered trademarks or trademarks of
Microsoft Corporation in the United States and/or other countries.
 
Pentium(r) is a trademark or registered trademark of Intel Corporation or its 
subsidiaries in the United States and other countries.


Final Special Thanks from BioWare
---------------------------------

Since the manual and credits movie were completed prior to the game being 
completed, certain people may not be listed in the manual who are listed in 
the credits movie. Please view the credits movie for the most complete list 
of development (BioWare) and publisher (Infogrames/Atari) credits.  

In addition to the people listed in the manual and credits movies, BioWare wishes 
to also thank Jason Booth and others at BioWare for providing quality assurance 
testing and suggestions, and also to thank our hundreds of beta testers 
for their valuable input, bug reports and suggestions.  

In memory of Dan Walker.

Finally, BioWare wishes to thank our fans for their support over the years for all 
of our products - we have worked very hard to try to make Neverwinter all 
that it could be, and we humbly hope that you enjoy the game!

Sincerely, 

Trent Oster - Project Director/Producer; 
Ray Muzyka - Co-Executive Producer/Joint CEO; 
Greg Zeschuk - Co-Executive Producer/Joint CEO;
and the rest of the Neverwinter Nights team at BioWare Corp.


