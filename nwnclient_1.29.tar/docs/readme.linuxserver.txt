Neverwinter Nights Linux (x86) Dedicated Server

Please visit http://nwn.bioware.com/ for updates and further information.

Running the Server:

The server executable is nwserver.  There are a number of command-line 
options available when running nwserver.  Running 'nwserver -help' will 
provide an up-to-date list list.  Once nwserver is running, you may enter
'help' to get the current list of commands available to you.

Command-Line Options:

-module <name>
      Loads and runs the specified module.  The module name is the name
      without the extension of a module file from your 'nwm' or 
      'modules' directory

-load <slot#>
      Loads and runs the specified saved game.  Saved games are located
      in the saves directory of your installation

-maxclients #
      Set the maximum number of connections to the game server

-minlevel #
      Set the minimum character level required by the server

-maxlevel #
      Set the maximum character level allowed by the server

-pauseandplay 0/1
      0 = game can only be paused by DM, 1 = game can by paused by 
      players

-pvp 0/1
      0 = none, 1 = party, 2 = full

-servervault 0/1
      0 = local characters only. 1 = server characters only

-elc 0/1
      0 = don't enforce legal characters, 1 = do enforce legal characters

-ilr 0/1
      0 = don't enforce item level restrictions, 1 = do enforce item 
      level restrictions

-gametype #
      Set which game room to post the game to (if game is posted to the 
      Internet)

-oneparty 0/1
      0 = allow multiple parties, 1 = allow only one party 

-difficulty #
      1 = easy, 2 = normal, 3 = D&D hardcore, 4 = very difficult

-autosaveinterval #
      Set how frequently (in minutes) to autosave.  0 disables autosave

-playerpassword <password>
      Set the password required by players to join the game

-dmpassword <password>
      Set the password required by DMs to DM the game

-servername <name>
      Set the name this server appears as in the mulitplayer game listing

-publicserver 0/1
      0 = do not list server with the matching service. 1 = list server 
      with the matching service

-reloadwhenempty 0/1
      0 = module state is persistant as long as server is running, 
      1 = module state is reset when the server becomes empty

-port #
      Specify the port to listen on for the server

-quiet
      Run without printing to stdout or reading from stdin, will run in
      background.  Warning, if specify -quiet you will not be able to
      manually save the game and it is recommended that you specify
      a value for autosaveinterval

-interactive
      Prints to stdout and reads from stdin, will not run while in 
      background.  This is the default mode of operation

-help
      List command line options

Default settings:

Command line parameters override nwnplayer.ini settings which override
hard coded defaults.

------------------------------------------------------------------------
 Command Line     | INI Section / Setting                     | Default
------------------+-------------------------------------------+---------
-maxclients       | Server Options / Max Players              | 6 
-minlevel         | Server Options / MinCharLevel             | 1
-maxlevel         | Server Options / MaxCharLevel             | 20
-pauseandplay     | Server Options / PauseAndPlay             | 0
-pvp              | Server Options / PVP Setting              | 1
-servervault      | INVERSE OF                                |
                  | Server Options / AllowLocalChars          | 0
-elc              | Server Options / Enforce Legal Characters | 1
-ilr              | Server Options / ItemLevelRestrictions    | 1
-gametype         | Server Options / Game Type                | 0
-oneparty         | Server Options / One Party Only           | 1
-difficulty       | Game Options / Difficulty Level           | 2
-autosaveinterval | Server Options / Auto Save Interval       | 0
                  | Server Options / Disable AutoSave         | 0
-playerpassword   | Server Options / PlayerPassword           | none
-dmpassword       | Server Options / DMPassword               | disabled
-servername       | Server Options / Server Name              | "Server"
-publicserver     | Server Options / GameSpy Enabled          | 1
-reloadwhenempty  | Server Options / Reload Module When Empty | 0
-port             | Server Options / Game Port                | 5121
------------------------------------------------------------------------

Interactive Commands:

status - Show information about the server.

clientinfo <player> - Displays details on the client identified by ID, 
		      CD Key, or Player Name.

kick <player> - Remove a player from the game identified by ID, CD Key, or
                Player Name.

listbans - List all the current bans for Name, IP, and Public CD Key.

banip <ip address> - Ban connections from an ip address (may include *s).
                     Banned addresses are stored in nwnplayer.ini under
		     [Banned Ips] on exit.

bankey <key> - Ban connections using a cd key.  Banned keys are stored in 
	       nwnplayer.ini under [Banned CD Keys] on exit.

banname <player name> - Ban connections from a player name (may start 
			and/or end with *s).  Banned names are stored in
                        nwnplayer.ini under [Banned Players] on exit.

unbanip <ip address> - Remove an ip address from the list of banned ip
                       addresses.

unbankey <key> - Remove a cd key the list of banned cd keys.

unbanname <player name> - Remove a player name from the list of banned 
			  player names.

save <slot#> <name> - Save the current running game and call it <name>.
		      Saved games are stored in your saves directory.
		      Only one saved game is allowed per slot, old saved
                      games may be manually deleted.  Slots 0 and 1 are
                      reserved for quicksave and autosave.

forcesave <slot#> <name> - Save the current running game and call it <name>,
                           overwriting any existing save game in that slot.

exit/quit - Shut down the server.

saveandexit <slot#> <name> - Save the current running game, call it 
                             <name> and shut down the server.

module <module name> - Load the specified module.  The module name is the 
		       name without the extension of a module file from 
		       your 'nwm' or 'modules' directory.

load <slot#> - Load the specified saved game.

say <message> - Broadcast a message to all clients.

export - Causes all player characters in the game to be saved.

maxclients <number of clients> - Set the maximum number of connections to 
                                 the game server.

minlevel <minumum level> - Set the minimum character level required by the 
                           server.

maxlevel <maximum level> - Set the maximum character level allowed by the 
                           server.

pauseandplay <0/1> - 0 = game can only be paused by DM
                     1 = game can by paused by players

elc <0/1> - 0 = don't enforce legal characters
            1 = do enforce legal characters

ilr <0/1> - 0 = don't enforce item level restrictions
            1 = do enforce item level restrictions

oneparty <0/1> - 0 = allow only one party
                 1 = allow multiple parties

difficulty <level> - 1 = easy
                     2 = normal
                     3 = D&D hardcore
                     4 = very difficult

autosaveinterval <time> - Set how frequently (in minutes) to autosave.  
                          0 disables autosave.

playerpassword <password>
      Change or set the password required by players to join the game.
      Providing no password will remove password protection.

dmpassword <password>
      Change or set the password required by DMs to DM the game.  Providing
      no password will disable DM login.

servername <name> - Set the name this server appears as in the mulitplayer 
                    game listing.

help - Display all commands.

Updating:

Linux dedicated server updates will be available as .tar.gz files.
Download locations and update instructions will be made available as 
updates are required.


NEVERWINTER NIGHTS Developed by BioWare Corp. 
 
C 2002 Atari Inc., S.A. All Rights Reserved. Manufactured
and marketed by Atari Inc.., New York, NY. Portions
C 2002 Bioware Corp. BioWare Aurora Engine copyright 1997-2002 BioWare Corp.
All Rights Reserved. BioWare, the BioWare Aurora Engine, and the
BioWare Logo are trademarks of BioWare Corp. All Rights Reserved.
Neverwinter Nights, Forgotten Realms, the Forgotten Realms logo,
Dungeons & Dragons logo, Dungeon Master, D&D, and the Wizards of the Coast
logo are trademarks owned by Wizards of the Coast, Inc., a subsidiary of
Hasbro, Inc. and are used by Atari Inc., S.A. under license.
All Rights Reserved. Windows and Windows 95/98/2000 are registered trademarks
of Microsoft Corporation. All Rights Reserved. The ratings icon is a trademark
of the Interactive Digital Software Association. All other trademarks and
copyrights are the property of their respective owners.
